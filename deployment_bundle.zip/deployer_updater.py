import boto3
import datetime
import requests
from apscheduler.schedulers.background import BackgroundScheduler
from botocore.exceptions import ClientError

# AWS CodeDeploy client
codedeploy = boto3.client('codedeploy')

# Configuration
REGION = 'us-east-1'  # Change as needed
ENDPOINT_URL = 'https://your-api-endpoint.com/success'  # Replace with your actual endpoint
APPLICATION_NAME = 'your-application-name'  # Replace with your CodeDeploy application name

def update_deployment_status():
    try:
        # List all deployments
        response = codedeploy.list_deployments(
            applicationName=APPLICATION_NAME,
            includeOnlyStatuses=['Ready']
        )
        
        deployments = response.get('deployments', [])
        
        if not deployments:
            print("No deployments in Ready state found")
            return
        
        # Update each Ready deployment to Successful
        successful_deployments = []
        for deployment_id in deployments:
            try:
                # Get deployment details
                deployment_info = codedeploy.get_deployment(
                    deploymentId=deployment_id
                )
                
                # Update deployment status to Successful
                codedeploy.update_deployment(
                    deploymentId=deployment_id,
                    targetStatus='Successful'
                )
                
                successful_deployments.append(deployment_id)
                print(f"Successfully updated deployment {deployment_id} to Successful")
                
            except ClientError as e:
                print(f"Error updating deployment {deployment_id}: {str(e)}")
        
        if successful_deployments:
            print(f"Updated {len(successful_deployments)} deployments to Successful")
            
    except ClientError as e:
        print(f"Error listing deployments: {str(e)}")

def make_api_call():
    try:
        # Prepare payload with current timestamp
        payload = {
            'timestamp': datetime.datetime.now().isoformat(),
            'message': 'Deployment status update completed'
        }
        
        # Make POST request
        response = requests.post(
            ENDPOINT_URL,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        response.raise_for_status()
        print(f"Successfully made POST request. Status code: {response.status_code}")
        
    except requests.exceptions.RequestException as e:
        print(f"Error making POST request: {str(e)}")

def schedule_tasks():
    # Create scheduler
    scheduler = BackgroundScheduler()
    
    # Schedule the API call for 4PM EST daily
    # Note: Using EST timezone (-5 UTC offset)
    scheduler.add_job(
        make_api_call,
        'cron',
        hour=16,  # 4PM EST = 20:00 UTC (adjust based on daylight savings if needed)
        minute=0,
        timezone='America/New_York'
    )
    
    # Start the scheduler
    scheduler.start()
    print("Scheduler started. Tasks will run at 4PM EST daily")

def main():
    try:
        # Initial run to update deployments
        print(f"Starting deployment status update at {datetime.datetime.now()}")
        update_deployment_status()
        
        # Schedule the daily API call
        schedule_tasks()
        
        # Keep the script running
        while True:
            pass
            
    except KeyboardInterrupt:
        print("\nShutting down...")
    except Exception as e:
        print(f"Unexpected error: {str(e)}")

if __name__ == "__main__":
    # Configure AWS credentials (should be set up in ~/.aws/credentials or environment variables)
    boto3.setup_default_session(region_name=REGION)
    main()